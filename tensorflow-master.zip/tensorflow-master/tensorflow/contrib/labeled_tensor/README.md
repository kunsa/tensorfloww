# Labels for TensorFlow

LabeledTensor is a library for adding semantically meaningful dimension and
coordinate labels to tensors in Tensorflow.

Maintainers:
- Stephan Hoyer (shoyer@google.com, github.com/shoyer)
- Eric Christiansen (ericmc@google.com, github.com/emchristiansen)
